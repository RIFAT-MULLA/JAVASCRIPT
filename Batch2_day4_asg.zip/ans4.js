let array = [
    {
        name : "Ayush",
        age : 35,
        country : "India",
        hobbies : ["reading","painting"],
    },
    {
        name : "Siddhi",
        age : 19,
        country : "India",
        hobbies : ["reading","painting"],
    },
    {
        name : "Anjali",
        age : "18",
        country : "Dubai",
        hobbies : ["reading","painting"]
    }

    ]


displayage(30);
displaycountry("India");

function displayage(age)
{
   for(let i=0;i<array.length;i++)
   {
       if(array[i].age<age)
	   {
	       console.log(array[i]);
	   }
   }

}
function displaycountry(str)
{
   for(let i=0;i<array.length;i++)
   {
       if(str==array[i].country)
		   
	       console.log(array[i]);
   
   }

};