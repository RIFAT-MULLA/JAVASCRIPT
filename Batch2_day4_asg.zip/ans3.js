let array = [{
        name : "Ayush",
        age : 35,
        country : "India",
        hobbies : ["reading","painting"],
    },
    {
        name : "Siddhi",
        age : 19,
        country : "India",
        hobbies : ["reading","painting"],
    },
    {
        name : "Anjali",
        age : "18",
        country : "Dubai",
        hobbies : ["reading","painting"]
    }

]

console.log(array);
